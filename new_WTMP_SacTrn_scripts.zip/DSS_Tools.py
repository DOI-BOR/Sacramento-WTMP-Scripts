#version 2.0
#modified 03-28-2023 by Scott Burdick-Yahya
#modifed Dec 2023 by Ben Saenz

from hec.heclib.dss import HecDss
from hec.io import DSSIdentifier
from hec.io import TimeSeriesContainer
from rma.util.RMAConst import MISSING_DOUBLE
from hec.hecmath import HecMathException
from hec.heclib.util.Heclib import UNDEFINED_DOUBLE
import hec.hecmath.TimeSeriesMath as tsmath
from com.rma.model import Project
import os,shutil,copy,sys,math
from java.util import Vector, Date

import datetime
from hec.heclib.util import HecTime


def copy_dss_ts(dss_rec,new_fpart=None,new_dss_rec=None,
                dss_file_path=None,dss_file_handle=None,dss_file_alt_outpath=None):

       # error check inputs - there are flexible way to copy record
    if dss_file_path is None and dss_file_handle is None:
        raise ValueError('copy_dss_rec_to_new_fpart: you must supply either a valid dss_file_path OR dss_file_handle')
    if new_fpart is None and new_dss_rec is None:
        raise ValueError('copy_dss_rec_to_new_fpart: you must supply either a new_fpart OR new_dss_rec')

    # (open dss) get record tsc
    if dss_file_handle is not None:
        dss_fm = dss_file_handle
        print('copy_dss_ts - reading input from open file:',dss_rec)
    else:
        dss_fm = HecDss.open(dss_file_path)
        print('copy_dss_ts - reading input:',dss_file_path,dss_rec)
    tsc = dss_fm.get(dss_rec,True)
    print('tsc.fullName',tsc.fullName)

    # new dss rec name
    if new_dss_rec is not None:
        dss_rec_out = new_dss_rec
    else:
        rec_parts = tsc.fullName.split('/')
        print(rec_parts)
        rec_parts[6] = new_fpart
        dss_rec_out = '/'.join(rec_parts)    

    # fix some terrible units along the way
    if tsc.units.lower() == 'degc':
        tsc.units = 'C'
    elif tsc.units.lower() == 'degf':
        tsc.units = 'F'

    # write
    tsc.fullName = dss_rec_out
    if dss_file_alt_outpath is not None:
        dss_fm_alt = HecDss.open(dss_file_alt_outpath)
        dss_fm_alt.put(tsc)
        dss_fm_alt.close()
    else:
        dss_fm.put(tsc)

    if dss_file_handle is None:
        dss_fm.close()

def jday_from_tsc(tsc):
    dtt = hectime_to_datetime(tsc)
    return [decimal_doy(dt) for dt in dtt]        


def decimal_doy(dt):
    doy = dt.timetuple().tm_yday
    fractional_day = (dt.hour / 24.0) + (dt.minute / 1440.0) + (dt.second / 86400.0) + (dt.microsecond / 86400000000.0)
    return doy + fractional_day


def organizeLocations(curAlt, location_objs, loc_names, return_dss_paths=False):
    locations_list = []
    print('num_locs:',len(location_objs))
    for name in loc_names:
        i_loc = findLocationOrder(curAlt,location_objs,name)
        print('name:',name,'i_loc:',i_loc)
        if return_dss_paths:
            lo1 = location_objs[i_loc]
            print(lo1)
            if lo1.isLinkedToPreviousModel():
                tspath = str(currentAlternative.loadTimeSeries(location))
                tspath = fixInputLocationFpart(curAlt, tspath)
            else:
                tspath = str(lo1.getDssPath())
            print(tspath)
            locations_list.append(tspath)
        else:
            locations_list.append(location_objs[i_loc])
    return locations_list


def organizeLocationsPaired(curAlt, location_objs, loc_names_paired, return_dss_paths=False):   
    return [organizeLocations(curAlt, location_objs, pn, return_dss_paths) for pn in loc_names_paired]


def findLocationOrder(curAlt,location_objs,name):
    for i,loc in enumerate(location_objs):
        print(i,'Checking loc: ',loc.getName())
        print('loc:',loc)
        if name == loc.getName():
            return i
    # if we make it here, our input/output location name was not found
    curAlt.addComputeMessage("Scripting - Location name not found: "+name)
    sys.exit(1)

def first_value(dss_file,dss_rec,start_str=None,end_str=None):
    dssFm = HecDss.open(dss_file)        
    if start_str is None and end_str is None:
        tsc = dssFm.get(dss_rec,True)
    else:
        tsc = dssFm.read(dss_rec,start_str,end_str,False).getData()
    dssFm.close()
    return tsc.values[0]


def standardize_interval(tsm, interval, makePerAver=True):
    tsc = tsm.getData()
    if interval.lower()=='1hour':
        intint = 60
    elif interval.lower()=='1day':
        intint=1440
    elif interval.lower()=='1week':
        intint=10800
    else:
        print('interval not supported:',interval)
        sys.exit(-1)

    if tsc.interval != intint:
        if makePerAver:
            #tsc.type = 'PER-AVER'  # make sure it's per-aver ... we are
            tsm.setType('PER-AVER')
        return tsm.transformTimeSeries(interval, "", "AVE")
    else:
        return tsm


def get_sanitized_record_list(dss_file_path):
    '''The DSS library seems to return lists of paths with dates in them (getPathnameList()), and some of those
    dates don't even exist in the file or cannot be read and throw an error.  As of Jan 2024,
    this is an orregular problem, and the manual soluation is throwing away the DSS file but
    in many cases that is problematic. So, here we filter dates and check for duplicates.'''
    dss = HecDss.open(dss_file_path)
    recs = dss.getPathnameList()
    dss.close()
    sanitized_recs = []
    for r in recs:
        rec_tokens = r.split('/')
        rec_tokens[4] = ''  # erase date string, if it exists
        r_sanitized = '/'.join(rec_tokens)
        if not r_sanitized in sanitized_recs:
            sanitized_recs.append(r_sanitized)
    return sanitized_recs  

def hectimes_from_tsm(tsm):
    times = tsm.getContainer().times
    htimes = []
    for i in range(tsm.getContainer().numberValues):
        htimes.append(HecTime())
        htimes[-1].set(times[i])
    return htimes

def hectimes_from_tsc(tsc):
    htimes = []
    for i in range(tsc.numberValues):
        htimes.append(HecTime())
        htimes[-1].set(tsc.times[i])
    return htimes


def shift_pit_river_time(input_dss_file,dss_rec,output_dss_file,out_rec,start_date=None,end_date=None):
    # important to not have dss_rec==out_rec, otherwise you will continually shift the record in time
    # whenever the calling script runs...    

    tsm_pit = dss_read_ts_safe(input_dss_file,dss_rec,start_date=start_date,end_date=end_date,returnTSM=True)

    tsm_pit = tsm_pit.shiftInTime("-12Hour")
    tsc_pit = tsm_pit.getData()
    tsc_pit.fullName = out_rec  

    dss_out = HecDss.open(output_dss_file)
    dss_out.put(tsc_pit)
    dss_out.close()


def shift_ts_time(input_dss_file,dss_rec,output_dss_file,out_rec,shift_str,start_date=None,end_date=None):
    ''' important to not have dss_rec==out_rec, otherwise you will continually shift the record in time
    whenever the calling script runs...

    shift_str is HEC-known string, with a possible negative on the front. E.g., '-12Hour','5Day'...
    '''  

    tsm = dss_read_ts_safe(input_dss_file,dss_rec,start_date=start_date,end_date=end_date,returnTSM=True)

    tsm = tsm.shiftInTime(shift_str)
    tsc = tsm.getData()
    tsc.fullName = out_rec  

    dss_out = HecDss.open(output_dss_file)
    dss_out.put(tsc)
    dss_out.close()


def dss_read_ts_safe(dssFilePath,dssRec,start_date=None,end_date=None,returnTSM=False,
                     returnPydatetimes=False,debug=False):
    '''A read function that is date-flexible, and ensures the whole time range is returned if dates
    are None.'''

    # this method is going to throw an error if the file doesn't exist
    dss = HecDss.open(dssFilePath,True)

    # recordExists() seems to check for the individual database "pages" or something, with a date, or
    # date range, required?  TODO: figure out how to check if a date-agnostic record exists.  Or, don't,
    # since HECLIB produces a pretty nice error if you try to open a non-existant record.
    #if not dss.recordExists(dssRec):
    #    print('DSS rec does not exist for reading:')
    #    print('File: '+dssFilePath)
    #    print('Rec: '+dssRec)
    #    sys.exit(-1)
    #else:
    if start_date is None and end_date is None:
        tsc = dss.get(dssRec,True) # use get with True here to capture entire record, 'read' seems to leave off data randomly
        dss.close()
        if debug:
            print('Reading DSS in script...')
            print('    file: '+dssFilePath)
            print('    record: '+dssRec)
        if returnTSM:
            return tsmath(tsc)
        else:
            return tsc
    elif start_date is not None and end_date is not None:
        tsm = dss.read(dssRec,start_date,end_date,False) # 'read' allows time windows in call, but returns tsm
        dss.close()
        if debug:
            print('Reading DSS in script between '+start_date+' and ',+end_date)
            print('    file: '+dssFilePath)
            print('    record: '+dssRec)
        if returnTSM:
            return tsm
        else:
            return tsm.getData()


def data_from_dss(dss_file,dss_rec,starttime_str, endtime_str):
    dssFm = HecDss.open(dss_file)
    if starttime_str is None and endtime_str is None:
        tsc = dssFm.get(dss_rec,True)
    else:
        tsc = dssFm.read(dss_rec, starttime_str, endtime_str, False).getData()
    dssFm.close()
    return tsc.values


def hectime_to_datetime(tsc):

    dtt = []
    for j in range(tsc.numberValues):
        # Assuming hectime can be converted to Java Date or has method to get the equivalent
        java_date = tsc.getHecTime(j).getJavaDate(0)  
        
        # Convert Java Date to Python datetime
        timestamp = (java_date.getTime() / 1000)
        dtt.append(datetime.datetime.fromtimestamp(timestamp))

    return dtt

def fixInputLocationFpart(currentAlternative, tspath):
    new_fpart_start = ':'.join(currentAlternative.getInputFPart().split(':')[:-1])
    tspath = tspath.split('/')
    fpart = tspath[6]
    fpart_split = fpart.split(':')
    new_fpart = new_fpart_start + ':' + fpart_split[-1]
    tspath[6] = new_fpart
    tspath = '/'.join(tspath)
    return tspath

def appendAPart(current_path, ApartAppend):
    tspath = tspath.split('/')
    Apart = tspath[1]
    if len(Apart) == 0:
        new_Apart = ApartAppend
    else:
        new_Apart = Apart + '_' + ApartAppend
    tspath[1] = new_Apart
    tspath = '/'.join(tspath)
    return tspath

def getDataLocationDSSInfo(location, currentAlternative, computeOptions):
    if location.isLinkedToPreviousModel():
        tspath = str(currentAlternative.loadTimeSeries(location))
        tspath = fixInputLocationFpart(currentAlternative, tspath)
        dsspath = computeOptions.getDssFilename()
    else:
        tspath = location.getLinkedToLocation().getDssPath()
        rundir = Project.getCurrentProject().getProjectDirectory()
        dsspath = location.getLinkedToLocation().get_dssFile()
        dsspath = os.path.join(rundir, dsspath)
    return tspath, dsspath

def strip_templateID_and_rename_records(dssFilePath,currentAlt):

    # make copy of dss file
    shutil.copyfile(dssFilePath,dssFilePath+'.bak')

    # rename all records, stripping first 4 chars from f-part
    dss = HecDss.open(dssFilePath)
    rec_names = dss.getPathnameList()
    new_rec_names = Vector()
    #currentAlt.addComputeMessage(type(rec_names).__name__)
    for i,r in enumerate(rec_names):        
        #currentAlt.addComputeMessage(type(r).__name__)        
        parts = r.split('/')
        if not '-' in parts[-2]:
            return
        parts[-2] = parts[-2][4:]
        new_rec_names.add('/'.join(parts))
        currentAlt.addComputeMessage('Fixing path: '+r+' --> '+new_rec_names[-1])
        #currentAlt.addComputeMessage(type(new_rec_names).__name__)
        #currentAlt.addComputeMessage(type(new_rec_names[i]).__name__)
        #if i==2:
        #    break
    dss.renameRecords(rec_names, new_rec_names)
    #currentAlt.addComputeMessage(type(new_rec_names).__name__)
    dss.close()

def add_DSS_Data(currentAlt, dssFile, timewindow, input_data, output_path):
    starttime_str = timewindow.getStartTimeString()
    endtime_str = timewindow.getEndTimeString()
    currentAlt.addComputeMessage('Looking from {0} to {1}'.format(starttime_str, endtime_str))
    dssFm = HecDss.open(dssFile)
    output_data = []
    for dsspath in input_data:
        print('reading', str(dsspath))
        ts = dssFm.read(dsspath, starttime_str, endtime_str, False)
        ts = ts.getData()
        values = ts.values
        times = ts.times
        units = ts.units
        dsstype = ts.type
        if len(output_data) == 0:
            output_data = values
        else:
            for vi, val in enumerate(values):
                output_data[vi] += val
                
    tsc = TimeSeriesContainer()
    tsc.times = times
    tsc.fullName = output_path
    tsc.values = output_data
    tsc.startTime = times[0]
    tsc.units = units
    tsc.type = dsstype
    tsc.endTime = times[-1]
    tsc.numberValues = len(output_data)
    tsc.startHecTime = timewindow.getStartTime()
    tsc.endHecTime = timewindow.getEndTime()
    dssFm.write(tsc)
    dssFm.close()
    currentAlt.addComputeMessage("Number of Written values: {0}".format(len(output_data)))
    return 0

def resample_dss_ts(inputDSSFile, inputRec, timewindow, outputDSSFile, newPeriod, lookback_1mon=False, pad_start_days=0):
    '''Can upsample an even period DSS timeseries, e.g. go from 1DAY -> 1HOUR, or downsample.  However, hecmath likes to
    clip of days that don't have the complete 24 hour cycle.  So, we pad here, but there is a chance we ask for data not
    available. The read gives garbage data and doesn't complain.  
    TODO: figure out how to check for bounds for non-midnight start and end times.
    '''
    dssFm = HecDss.open(inputDSSFile)
    if timewindow is not None:
        starttime_str = timewindow.getStartTimeString()
        endtime_str = timewindow.getEndTimeString()
        #if newPeriod.lower() == '1day':  # some computes don't end on 2400, causes problems when last day doesn't get produced in this func
        starttime_str = starttime_str[:-4] + '0000'
        endtime_str = endtime_str[:-4] + '2400' # clipped days don't work in computes ... hope the downloaded DMS data is long enough to do this.
        if pad_start_days > 0:
            dt_start = hec_str_time_to_dt(starttime_str) - datetime.timedelta(days=pad_start_days)
            starttime_str = dt_start.strftime('%d%b%Y %H%M')
        if lookback_1mon:
            dt_start = hec_str_time_to_dt(starttime_str) - datetime.timedelta(days=-31)
            starttime_str = dt_start.strftime('%d%b%Y %H%M')      
        print('Resampling',newPeriod, inputRec,starttime_str,endtime_str)
        tsm = dssFm.read(inputRec, starttime_str, endtime_str, False)
    else:
        print('Resampling',newPeriod, inputRec)
        tsm = dssFm.read(inputRec)  # caution - 'read' sometimes doesn't get whole record?  Need to use get?

    tsm_new = tsm.transformTimeSeries(newPeriod,"","AVE")
    dssFm.close()

    dssFmout = HecDss.open(outputDSSFile)
    dssFmout.write(tsm_new)
    dssFmout.close()


def airtemp_lapse(dss_file,dss_rec,lapse_in_C,dss_outfile,f_part):
    dss = HecDss.open(dss_file)
    tsm = dss.read(dss_rec)
    lapse = lapse_in_C
    if 'f' in tsm.getUnits().lower():
        lapse = lapse*9.0/5.0+32.0
    tsm = tsm.add(lapse)
    tsc = tsm.getData()
    dss.close()

    pathparts = dss_rec.split('/')
    pathparts[-2] = f_part
    tsc.fullName = '/'.join(pathparts)
    dss_out = HecDss.open(dss_outfile)
    dss_out.write(tsc)
    dss_out.close()

def min_ts(dss_file,dss_rec,min_value,dss_outfile,f_part):
    dss = HecDss.open(dss_file)
    tsc = dss.get(dss_rec,True)
    dss.close()

    for vi, v in enumerate(tsc.values):
        tsc.values[vi] = max(v, min_value)

    pathparts = dss_rec.split('/')
    pathparts[-2] = f_part
    tsc.fullName = '/'.join(pathparts)
    dss_out = HecDss.open(dss_outfile)
    dss_out.write(tsc)
    dss_out.close()

def add_flows(currentAlt, timewindow, inflow_records, dss_file, output_dss_record_name, output_dss_file):
     
    #cfs_2_acreft = balance_period * 3600. / 43559.9
    #acreft_2_cfs = 1. / cfs_2_acreft

    starttime_str = timewindow.getStartTimeString()
    endtime_str = timewindow.getEndTimeString()
    #01Jan2014 0000
    starttime_hectime = HecTime(starttime_str).value()
    endtime_hectime = HecTime(endtime_str).value()
    currentAlt.addComputeMessage('Looking from {0} to {1}'.format(starttime_str, endtime_str))
    dssFm = HecDss.open(dss_file)

    inflows = []
    times = []

    # Read inflows
    print('Reading inflows')
    for j, inflow_record in enumerate(inflow_records): #for each of the dss paths in inflow_records
        pathname = inflow_record
        currentAlt.addComputeMessage('reading' + str(pathname))
        print('\nreading' + str(pathname))
        try:
       
            print(starttime_str, endtime_str)
            if '::' in inflow_record:
                dss_file_alt,inflow_rec_alt = inflow_record.split('::')
                dssFm_alt = HecDss.open(dss_file_alt)
                ts = dssFm_alt.read(inflow_rec_alt, starttime_str, endtime_str, False)
                dssFm_alt.close()
                print(dss_file_alt)
            else:
                print(dss_file)
                ts = dssFm.read(pathname, starttime_str, endtime_str, False)
            ts_data = ts.getData()
            values = ts_data.values
            hectimes = ts_data.times
            units = ts_data.units
            tstype = ts_data.type
            # print('num values {0}'.format(len(values)))
            # print('start {0}'.format(ts_data.getStartTime()))
            # print('end {0}'.format(ts_data.getEndTime()))
            if hectimes[0] < starttime_hectime: #if startdate is before the timewindow..
                print('start date ({0}) from DSS before timewindow ({1})..'.format(hectimes[0], starttime_hectime))
                st_offset = (starttime_hectime - hectimes[0]) / (hectimes[1] - hectimes[0])
                values = values[st_offset:]
                hectimes = hectimes[st_offset:]
            if hectimes[-1] > endtime_hectime:
                print('end date ({0}) from DSS after timewindow ({1})..'.format(hectimes[-1], endtime_hectime))
                st_offset = (hectimes[-1] - endtime_hectime) / (hectimes[1] - hectimes[0])
                values = values[:(len(hectimes) - st_offset)]
                hectimes = hectimes[:(len(hectimes) - st_offset)]
                

        except HecMathException:
            currentAlt.addComputeMessage('ERROR reading' + str(pathname))
            sys.exit(-1)

        if units.lower() == 'cms':
            currentAlt.addComputeMessage('Converting cms to cfs')
            convvals = []
            for flow in values:
                convvals.append(flow * 35.314666213)
            values = convvals

        if len(inflows) == 0:
            inflows = values
            times = hectimes #TODO: check how this handles missing values
        else:
            for vi, v in enumerate(values):
                inflows[vi] += v

    # Output record
    tsc = TimeSeriesContainer()
    tsc.times = times
    tsc.fullName = output_dss_record_name
    tsc.values = inflows
    #tsc.startTime = times[1]
    tsc.units = 'CFS'
    tsc.type = tstype
    #tsc.endTime = times[-1]
    tsc.numberValues = len(inflows)
    #tsc.startHecTime = timewindow.getStartTime()
    #tsc.endHecTime = timewindow.getEndTime()
    dssFm_out = HecDss.open(output_dss_file)
    dssFm_out.write(tsc)

    dssFm.close()
    dssFm_out.close()


def add_or_subtract_flows(currentAlt, timewindow, inflow_records, dss_file, operation,
                       output_dss_record_name, output_dss_file, what="flow", prepend_n=0):
    # operation: list where True = add, False = subtract, e.g. [True,False,True] to substract the 2nd
    # record from the sum of the first and third records
    # what == "flow": assume flows and rectify units
    # what == anything else: use what as units, and don't convert anything

    starttime_str = timewindow.getStartTimeString()
    endtime_str = timewindow.getEndTimeString()
    #01Jan2014 0000
    starttime_hectime = HecTime(starttime_str).value()
    endtime_hectime = HecTime(endtime_str).value()
    currentAlt.addComputeMessage('add_or_subtract_flows - Looking from {0} to {1}'.format(starttime_str, endtime_str))
    dssFm = HecDss.open(dss_file)

    inflows = []
    times = []

    # Read inflows
    print('Reading inflows')
    
    for j, inflow_record in enumerate(inflow_records): #for each of the dss paths in inflow_records
        pathname = inflow_record
        currentAlt.addComputeMessage('reading' + str(pathname))
        print('\nreading' + str(pathname))
        try:
       
            print(starttime_str, endtime_str)
            if '::' in inflow_record:
                dss_file_alt,inflow_rec_alt = inflow_record.split('::')
                dssFm_alt = HecDss.open(dss_file_alt)
                ts = dssFm_alt.read(inflow_rec_alt, starttime_str, endtime_str, False)
                dssFm_alt.close()
                print(dss_file_alt)
            else:                
                ts = dssFm.read(pathname, starttime_str, endtime_str, False)                
                print(dss_file)
            ts_data = ts.getData()
            values = ts_data.values
            hectimes = ts_data.times
            units = ts_data.units
            tstype = ts_data.type
            # print('num values {0}'.format(len(values)))
            # print('start {0}'.format(ts_data.getStartTime()))
            # print('end {0}'.format(ts_data.getEndTime()))
            if hectimes[0] < starttime_hectime: #if startdate is before the timewindow..
                print('start date ({0}) from DSS before timewindow ({1})..'.format(hectimes[0], starttime_hectime))
                st_offset = (starttime_hectime - hectimes[0]) / (hectimes[1] - hectimes[0])
                values = values[st_offset:]
                hectimes = hectimes[st_offset:]
            if hectimes[-1] > endtime_hectime:
                print('end date ({0}) from DSS after timewindow ({1})..'.format(hectimes[-1], endtime_hectime))
                st_offset = (hectimes[-1] - endtime_hectime) / (hectimes[1] - hectimes[0])
                values = values[:(len(hectimes) - st_offset)]
                hectimes = hectimes[:(len(hectimes) - st_offset)]
                

        except HecMathException:
            currentAlt.addComputeMessage('ERROR reading' + str(pathname))
            sys.exit(-1)

        if what=="flow":
            if units.lower() == 'cms':
                currentAlt.addComputeMessage('Converting cms to cfs')
                convvals = []
                for flow in values:
                    convvals.append(flow * 35.314666213)
                values = convvals

        if len(inflows) == 0:
            inflows = values
            times = hectimes #TODO: check how this handles missing values
        else:
            if operation[j]:
                for vi, v in enumerate(values):
                    inflows[vi] += v
            else:
                for vi, v in enumerate(values):
                    inflows[vi] -= v

    if prepend_n > 0:
        # add first value onto front of record
        # Sometimes ResSim needs some lookback values, or whatever
        p_times = [times[i] for i in range(len(times))] # convert to list - annoying
        time_delta = times[1] -times[0]
        times = [p_times[0] - time_delta*i for i in range(prepend_n,0,-1)] + p_times
        values = [inflows[i] for i in range(len(inflows))] # convert to list - annoying
        inflows = [values[0]]*prepend_n + values
                    
    # Output record
    tsc = TimeSeriesContainer()
    tsc.times = times
    tsc.fullName = output_dss_record_name
    tsc.values = inflows
    #tsc.startTime = times[1]
    if what=="flow":
        tsc.units = 'CFS'
    else:
        tsc.units = what
    tsc.type = tstype
    #tsc.endTime = times[-1]
    tsc.numberValues = len(inflows)
    #tsc.startHecTime = timewindow.getStartTime()
    #tsc.endHecTime = timewindow.getEndTime()
    dssFm_out = HecDss.open(output_dss_file)
    dssFm_out.write(tsc)

    dssFm.close()
    dssFm_out.close()


def hec_str_time_to_dt(hec_str_time):
    '''Convert HEC date time format to python datetime object'''

    dt_format = '%d%b%Y %H%M'
    add_day = False
    if hec_str_time.endswith('2400'):
        my_hec_str_time = hec_str_time[:-4] + '0000'
        add_day = True
    else:
        my_hec_str_time = hec_str_time

    dt = datetime.datetime.strptime(my_hec_str_time,dt_format)
    if add_day:
        dt = dt + datetime.timedelta(days=1)
    return dt


def create_constant_dss_rec(currentAlt, timewindow, output_dss_file, constant=0.0, what='flow', 
                        dss_type='PER-AVER', period='1HOUR',cpart='ZEROS', fpart='ZEROS'):
    '''Create and write a dss record with a constant in it for the given time windows.
       what={'flow','temp-water'}
       period={'1HOUR','1DAY'}
    '''

    if what.lower()=='flow':
        units = 'cfs'
        parameter = 'flow'
    elif what.lower()=='temp-water':
        units = 'C'
        parameter = 'temp-water'
    elif what.lower()=='gate':
        units = 'n/a'
        parameter = 'gate'
    elif what.lower()=='evap':
        units = 'ft'
        parameter = 'evap'
    elif what.lower()=='elev':
        units = 'ft'
        parameter = 'elev'
    else:
        currentAlt.addComputeMessage('create_zero_dss_rec: what not known: %s'%what)
        return False

    if period.lower()=='1hour':
        pass
    elif period.lower()=='1day':
        pass
    else:
        currentAlt.addComputeMessage('create_zero_dss_rec: period not known: %s'%period)
        return False

    dt_format = '%d%b%Y %H%M'
    
    starttime_str = timewindow.getStartTimeString()
    endtime_str = timewindow.getEndTimeString()
    #starttime_hectime = HecTime(starttime_str).value()
    #endtime_hectime = HecTime(endtime_str).value()

    # pad 1 day on records, in case these are used for lookbacks, or balance flow calcs, etc.
    starttime_dt = hec_str_time_to_dt(starttime_str) - datetime.timedelta(days=1)    
    endtime_dt = hec_str_time_to_dt(endtime_str) + datetime.timedelta(days=1)
    starttime_str_pad = starttime_dt.strftime(dt_format)
    endtime_str_pad = endtime_dt.strftime(dt_format)    
 
    currentAlt.addComputeMessage('Looking from {0} to {1}'.format(starttime_str, endtime_str))

    ########################
    # Zero-Flow Time Series
    ########################

    tsmath_zero_flow_day = tsmath.generateRegularIntervalTimeSeries(
        starttime_str_pad,
        endtime_str_pad,
        period, "0M", constant)
    tsmath_zero_flow_day.setUnits(units)
    tsmath_zero_flow_day.setType(dss_type)
    tsmath_zero_flow_day.setTimeInterval(period)
    tsmath_zero_flow_day.setLocation(cpart)
    tsmath_zero_flow_day.setParameterPart(parameter)
    tsmath_zero_flow_day.setVersion(fpart)

    dssFm = HecDss.open(output_dss_file)
    dssFm.write(tsmath_zero_flow_day)
    dssFm.close()

    return True


def calculate_relative_humidity(air_temp, dewpoint_temp):
    """
    Calculate Relative Humidity given the air temperature and dewpoint temperature - August-Roche-Magnus approximation

    :param air_temp: Air Temperature in degrees Celsius
    :param dewpoint_temp: Dew Point Temperature in degrees Celsius
    :return: Relative Humidity in percentage
    """
    numerator = (112.0 - 0.1 * dewpoint_temp + air_temp)
    denominator = (112.0 + 0.9 * air_temp)
    exponent = ((17.62 * dewpoint_temp) / (243.12 + dewpoint_temp)) - ((17.62 * air_temp) / (243.12 + air_temp))
    relative_humidity = 100.0 * (numerator / denominator) * math.exp(exponent)
    return max(0.01, min(100.0, relative_humidity))

def calculate_dewpoint(air_temp, relative_humidity):
    """
    Calculate Dew Point Temperature given the air temperature and relative humidity,
    using the algebraic inversion of the simplified August-Roche-Magnus approximation.
    
    Parameters:
        air_temp (float): Air temperature in C.
        relative_humidity (float): Relative Humidity in percent (0-100).
    
    Returns:
        float: Dew Point Temperature in C.
    """
    gamma = math.log(relative_humidity / 100.0) + (17.62 * air_temp) / (243.12 + air_temp)
    dewpoint = 243.12 * gamma / (17.62 - gamma)
    return dewpoint


def relhum_from_at_dp(met_dss_file, at_path, dp_path):
    dss = HecDss.open(met_dss_file)
    tsc = dss.read(at_path).getData()
    dp_data = data_from_dss(met_dss_file, dp_path, None, None)
    for i in range(tsc.numberValues):
        tsc.values[i] = calculate_relative_humidity(tsc.values[i], dp_data[i])
    parts = tsc.fullName.split('/')
    parts[2] = parts[2][:5]
    parts[3] = 'RELHUM-FROM-AT-DP'
    parts[6] = parts[6] + '-DERIVED'
    new_pathname = '/'.join(parts)
    tsc.fullName = new_pathname
    tsc.units = '%'
    print('writing: ', new_pathname)
    dss.write(tsc)
    dss.close()


def dp_from_at_relhum(met_dss_file, at_path, rh_path):
    dss = HecDss.open(met_dss_file)
    tsc = dss.read(at_path).getData()
    rh_data = data_from_dss(met_dss_file, rh_path, None, None)
    for i in range(tsc.numberValues):
        #print('AT:',tsc.values[i], 'RH:',rh_data[i])
        tsc.values[i] = calculate_dewpoint(tsc.values[i], rh_data[i])
    parts = tsc.fullName.split('/')
    parts[2] = parts[2][:5]
    parts[3] = 'temp-dewpoint'
    parts[6] = parts[6] + '-DERIVED'
    new_pathname = '/'.join(parts)
    tsc.fullName = new_pathname
    #tsc.units = '%' - units should be C...
    print('writing: ', new_pathname)
    dss.write(tsc)
    dss.close()

def check_start_and_end(values, times, startime, endtime):
    if times[0] < startime:  # if startdate is before the timewindow..
        print('start date ({0}) from DSS before timewindow ({1})..'.format(times[0], startime))
        st_offset = (startime - times[0]) / (times[1] - times[0])
        values = values[st_offset:]
        times = times[st_offset:]
    if times[-1] > endtime:
        print('end date ({0}) from DSS after timewindow ({1})..'.format(times[-1], endtime))
        st_offset = (times[-1] - endtime) / (times[1] - times[0])
        values = values[:(len(times) - st_offset)]
        times = times[:(len(times) - st_offset)]
    return values, times


def replace_data(currentAlt, timewindow, pairs, dss_file, dss_outfile, months, standard_interval=None):
    starttime_str = timewindow.getStartTimeString()
    endtime_str = timewindow.getEndTimeString()
    # 01Jan2014 0000
    starttime_hectime = HecTime(starttime_str).value()
    endtime_hectime = HecTime(endtime_str).value()
    currentAlt.addComputeMessage('Looking from {0} to {1}'.format(starttime_str, endtime_str))
    for pair in pairs:
        dssFm = HecDss.open(dss_file)
        currentAlt.addComputeMessage('Replacing data for {0} with {1} during {2}'.format(pair[0], pair[1], months))
        base = dssFm.read(pair[0], starttime_str, endtime_str, False)
        if standard_interval is not None:
            base = standardize_interval(base,standard_interval)
        base_data = base.getData()
        base_values = base_data.values
        base_hectimes = base_data.times
        base_units = base_data.units
        base_interval = base_data.interval
        base_type = base_data.type
        base_values, base_hectimes = check_start_and_end(base_values, base_hectimes, starttime_hectime, endtime_hectime)

        alt = dssFm.read(pair[1], starttime_str, endtime_str, False)
        if standard_interval is not None:
            alt = standardize_interval(alt,standard_interval)
        alt_data = alt.getData()
        alt_values = alt_data.values
        alt_hectimes = alt_data.times
        alt_units = alt_data.units
        alt_interval = alt_data.interval
        alt_values, alt_hectimes = check_start_and_end(alt_values, alt_hectimes, starttime_hectime, endtime_hectime)

        dssFm.close()

        if base_units != alt_units:
            currentAlt.addComputeMessage('Units do not match for {0} and {1}, skipping'.format(pair[0], pair[1]))
            dssFm.close()
            sys.exit(1)
        if base_interval != alt_interval:
            currentAlt.addComputeMessage('Intervals do not match for {0} and {1}, changing interval...'.format(pair[0], pair[1]))
            dssFm.close()
            sys.exit(1)

        for i in range(len(base_values)):
            if base_data.getHecTime(i).month() in months:
                base_values[i] = alt_values[i]
                #print('replaced {0}'.format(base_data.getHecTime(i)))

        new_pathname = base_data.fullName.split('/')
        alt_pathname = alt_data.fullName.split('/')
        new_pathname[-2] = 'MergedFrom_{0}'.format(alt_pathname[1])
        new_pathname = '/'.join(new_pathname)
        print('writing: ',new_pathname)
        tsc = TimeSeriesContainer()
        tsc.times = base_hectimes
        tsc.fullName = new_pathname
        tsc.values = base_values
        tsc.units = base_units
        tsc.type = base_type
        tsc.numberValues = len(base_values)

        dssFmOut = HecDss.open(dss_outfile)
        dssFmOut.write(tsc)

        dssFm.close()
        dssFmOut.close()

def airtemp_lapse(dss_file,dss_rec,lapse_in_C,dss_outfile,f_part):
    dss = HecDss.open(dss_file)
    tsm = dss.read(dss_rec)
    lapse = lapse_in_C
    if 'f' in tsm.getUnits().lower():
        lapse = lapse*9.0/5.0+32.0
    tsm = tsm.add(lapse)
    tsc = tsm.getData()
    dss.close()

    pathparts = dss_rec.split('/')
    pathparts[-2] = f_part
    tsc.fullName = '/'.join(pathparts)
    dss_out = HecDss.open(dss_outfile)
    dss_out.write(tsc)
    dss_out.close()

def preprend_first_value_on_ts(dss_file,dss_rec,prepend_n):
    '''Sometimes ResSim needs some lookback values, or whatever
    
    Be careful that the first record is where you want to start - sometimes these things change
    '''
    dss = HecDss.open(dss_file)
    tsc = dss.get(dss_rec,True)

    time_delta = tsc.times[1] - tsc.times[0]
    times = [tsc.times[i] for i in range(len(tsc.times))] # convert to list - annoying
    tsc.times = [times[0] - time_delta*i for i in range(prepend_n,0,-1)] + times
    tsc.startTime = tsc.times[0]
    values = [tsc.values[i] for i in range(len(tsc.values))] # convert to list - annoying
    tsc.values = [values[0]]*prepend_n + values
    tsc.numberValues = len(tsc.values)

    dss.put(tsc)
    dss.close()

def postprend_last_value_on_ts(dss_file,dss_rec,postpend_n):
    '''Sometimes ResSim needs some lookback values, or whatever
    has to be a 'regular' record'''
    dss = HecDss.open(dss_file)
    tsc = dss.get(dss_rec,True)

    time_delta = tsc.times[1] - tsc.times[0]
    times = [tsc.times[i] for i in range(len(tsc.times))] # convert to list - annoying
    tsc.times = times + [times[-1] + time_delta*i for i in range(1,postpend_n+1)]
    #tsc.startTime = tsc.times[0]
    values = [tsc.values[i] for i in range(len(tsc.values))] # convert to list - annoying
    tsc.values = values + [values[-1]]*postpend_n
    tsc.numberValues = len(tsc.values)

    dss.put(tsc)
    dss.close()   
